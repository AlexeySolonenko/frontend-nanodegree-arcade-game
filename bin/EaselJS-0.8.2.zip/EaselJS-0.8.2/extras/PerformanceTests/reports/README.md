# Performance Test Reports

By appending a "report" param, you can have the results from an auto test sent to a report template.

For example, the following will run the test five times for each version of the library, then send the results to the table.html report template for analysis.
myTest.html?auto=5&report=table